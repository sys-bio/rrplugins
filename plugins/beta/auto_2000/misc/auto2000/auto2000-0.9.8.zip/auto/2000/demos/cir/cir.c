#include "auto_f2c.h"
/* Common Block Declarations */

extern struct {
  integer itwist, istart, iequib, nfixed, npsi, nunstab, nstab;
} blhom_1;

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
/*   cir :    Homoclinic Bifurcation in an Electronic Circuit */
/*                (the same equations as in demo tor) */
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int func (integer ndim, const doublereal *u, const integer *icp,
          const doublereal *par, integer ijac,
          doublereal *f, doublereal *dfdu, doublereal *dfdp)
{
  /* System generated locals */
integer dfdu_dim1, dfdp_dim1;

  /* Local variables */
  doublereal r, x, y, z, a3, b3, be, ga, rn;

  dfdp_dim1 = ndim;
  dfdu_dim1 = ndim;

  /* Function Body */
  rn = par[0];
  be = par[1];
  ga = par[2];
  r = par[3];
  a3 = par[4];
  b3 = par[5];

  x = u[0];
  y = u[1];
  z = u[2];

  f[0] = (-(be + rn) * x + be * y - a3 * (x * (x * x)) + b3 * ((y-x) * ((y-x) * (y-x)))) / r;
  f[1] = be * x - (be + ga) * y - z - b3 * ((y-x) * ((y-x) * (y-x)));
  f[2] = y;

  if (ijac == 0) {
    return 0;
  }

  ARRAY2D(dfdu,0,0) = (-(be + rn) - a3 * 3 * (x * x) - b3 * 3 * ((y-x) * (y-x))) / r;
  ARRAY2D(dfdu,0,1) = (be + b3 * 3 * ((y-x) * (y-x))) / r;
  ARRAY2D(dfdu,0,2) = 0.;

  ARRAY2D(dfdu,1,0) = be + b3 * 3 * ((y-x) * (y-x));
  ARRAY2D(dfdu,1,1) = -(be + ga) - b3 * 3 * ((y-x) * (y-x));
  ARRAY2D(dfdu,1,2) = -1.;

  ARRAY2D(dfdu,2,0) = 0.;
  ARRAY2D(dfdu,2,1) = 1.;
  ARRAY2D(dfdu,2,2) = 0.;

  if (ijac == 1) {
    return 0;
  }
/*      *Parameter derivatives */
  ARRAY2D(dfdp,0,0) = -x / r;
  ARRAY2D(dfdp,0,1) = 0.;
  ARRAY2D(dfdp,0,2) = 0.;

  ARRAY2D(dfdp,1,0) = (-x + y) / r;
  ARRAY2D(dfdp,1,1) = x - y;
  ARRAY2D(dfdp,1,2) = 0.;

  ARRAY2D(dfdp,2,0) = 0.;
  ARRAY2D(dfdp,2,1) = -y;
  ARRAY2D(dfdp,2,2) = 0.;

  ARRAY2D(dfdp,3,0) = -f[0] / r;
  ARRAY2D(dfdp,3,1) = 0.;
  ARRAY2D(dfdp,3,2) = 0.;

  ARRAY2D(dfdp,4,0) = x * (x * x) / r;
  ARRAY2D(dfdp,4,1) = 0.;
  ARRAY2D(dfdp,4,2) = 0.;

  ARRAY2D(dfdp,5,0) = (y-x) * ((y-x) * (y-x)) / r;
  ARRAY2D(dfdp,5,1) = -((y-x) * ((y-x) * (y-x)));
  ARRAY2D(dfdp,5,2) = 0.;

  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int stpnt (integer ndim, doublereal t,
           doublereal *u, doublereal *par)
{
  /* ---------------------------------------------------------------------- */
  /* Problem parameters (only PAR(1-9) are available to the user) : */
  
  /* Function Body */
  par[0] = -.721309;
  /* nu */
  par[1] = (doublereal).6;
  /* beta */
  par[2] = (doublereal)0.;
  /* gamma */
  par[3] = (doublereal).6;
  /* r */
  par[4] = (doublereal).328578;
  /* a_3 */
  par[5] = (doublereal).933578;
  
  /* b_3 */
  par[10] = (doublereal)36.13;

  /* ---------------------------------------------------------------------- */
  /* If IEQUIB >0 put initial equilibrium in PAR(11+i), i=1,...,NDIM : */

  /* Truncated time interval */
  par[11] = (doublereal)0.;
  par[12] = (doublereal)0.;
  par[13] = (doublereal)0.;

  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int pvls (integer ndim, const doublereal *u,
          doublereal *par)
{
  /* Local variables */
integer i;

/* Homoclinic bifurcations COMMON block needed here : */

/* If IEQUIB =0 put analytic equilibrium in PAR(11+i), i=1..NDIM */
  if (blhom_1.iequib == 0) {
    for (i = 1; i <= ndim; ++i) {
      par[i + 11] = (doublereal)0.;
    }
  }

  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int bcnd (integer ndim, const doublereal *par, const integer *icp,
          integer nbc, const doublereal *u0, const doublereal *u1, integer ijac,
          doublereal *fb, doublereal *dbc)
{
  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int icnd (integer ndim, const doublereal *par, const integer *icp,
          integer nint, const doublereal *u, const doublereal *uold,
          const doublereal *udot, const doublereal *upold, integer ijac,
          doublereal *fi, doublereal *dint)
{
  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int fopt (integer ndim, const doublereal *u, const integer *icp,
          const doublereal *par, integer ijac,
          doublereal *fs, doublereal *dfdu, doublereal *dfdp)
{
  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
