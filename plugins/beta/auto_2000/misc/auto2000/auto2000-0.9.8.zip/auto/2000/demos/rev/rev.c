/* rev.c.3.f -- translated by f2c (version 19970805).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "auto_f2c.h"
/* Common Block Declarations */

extern struct {
    integer itwist, istart, iequib, nfixed, npsi, nunstab, nstab;
} blhom_1;


/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
/*   cir :    Homoclinic Bifurcation in an Electronic Circuit */
/*                (the same equations as in demo tor) */
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int func (integer ndim, const doublereal *u, const integer *icp,
          const doublereal *par, integer ijac,
          doublereal *f, doublereal *dfdu, doublereal *dfdp)
{
  /* System generated locals */
  integer dfdu_dim1, dfdp_dim1;
  doublereal d1, d2;
  
  /* Local variables */
  doublereal p;


  dfdp_dim1 = ndim;
  dfdu_dim1 = ndim;
  
  /* Function Body */
  p = par[0];
  
  f[0] = u[1];
  f[1] = u[2];
  f[2] = u[3];
  /* Computing 3rd power */
  d1 = u[0], d2 = d1;
  f[3] = -p * u[2] - u[0] + d2 * (d1 * d1);
  
  if (ijac == 0) {
    return 0;
  }
  
  ARRAY2D(dfdu,0,0) = 0.0;
  ARRAY2D(dfdu,1,0) = 1.0;
  ARRAY2D(dfdu,2,0) = 0.0;
  ARRAY2D(dfdu,3,0) = 0.0;
  
  ARRAY2D(dfdu,0,1) = 0.0;
  ARRAY2D(dfdu,1,1) = 0.0;
  ARRAY2D(dfdu,2,1) = 1.0;
  ARRAY2D(dfdu,3,1) = 0.0;
  
  ARRAY2D(dfdu,0,2) = 0.0;
  ARRAY2D(dfdu,1,2) = 0.0;
  ARRAY2D(dfdu,2,2) = 0.0;
  ARRAY2D(dfdu,3,2) = 1.0;
  
  /* Computing 2nd power */
  d1 = u[0];
  ARRAY2D(dfdu,0,3) = d1 * d1 * 3. - (doublereal)1.;
  ARRAY2D(dfdu,1,3) = 0.0;
  ARRAY2D(dfdu,2,3) = -p;
  ARRAY2D(dfdu,3,3) = 1.0;
  
  if (ijac == 1) {
    return 0;
  }
  /*      *Parameter derivatives */
  ARRAY2D(dfdp,0,0) = 0.0;
  ARRAY2D(dfdp,0,1) = 0.0;
  ARRAY2D(dfdp,0,2) = 0.0;
  ARRAY2D(dfdp,0,3) = -u[2];
  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int stpnt (integer ndim, doublereal t,
           doublereal *u, doublereal *par)
{
  /* Problem parameters (only PAR(1-9) are available to the user) : */

  par[0] = (doublereal)1.6;
  
  /* P */

  /* rev.c.1*/
  /*par[10] = (doublereal)39.0448429;*/
  /* rev.c.3*/
  par[10] = (doublereal)47.4464189;

  /* ----------------------------------------------------------------------*/
  /* If IEQUIB >0 put initial equilibrium in PAR(11+i), i=1,...,NDIM : */
  
  /* Truncated time interval */
  par[11] = (doublereal)0.;
  par[12] = (doublereal)0.;
  par[13] = (doublereal)0.;
  par[14] = (doublereal)0.;

  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int pvls (integer ndim, const doublereal *u,
          doublereal *par)
{
  /* Local variables */
  integer i;

  /* Homoclinic bifurcations COMMON block needed here : */
  
  /* If IEQUIB =0 put analytic equilibrium in PAR(11+i), i=1..NDIM */

  if (blhom_1.iequib == 0) {
    for (i = 0; i < ndim; ++i) {
      par[i + 11] = (doublereal)0.;
    }
  }

  return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int bcnd (integer ndim, const doublereal *par, const integer *icp,
          integer nbc, const doublereal *u0, const doublereal *u1, integer ijac,
          doublereal *fb, doublereal *dbc)
{
    return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int icnd (integer ndim, const doublereal *par, const integer *icp,
          integer nint, const doublereal *u, const doublereal *uold,
          const doublereal *udot, const doublereal *upold, integer ijac,
          doublereal *fi, doublereal *dint)
{
    return 0;
}

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
int fopt (integer ndim, const doublereal *u, const integer *icp,
          const doublereal *par, integer ijac,
          doublereal *fs, doublereal *dfdu, doublereal *dfdp)
{
    return 0;
}
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */

